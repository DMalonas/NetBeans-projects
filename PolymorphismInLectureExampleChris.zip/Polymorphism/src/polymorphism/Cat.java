/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polymorphism;

/**
 *
 * @author aa6164
 */
public class Cat extends Animal
{
    void aCatLikeMethod()
    {
        
    }
//    void makeNoise()
//    {
//        System.out.println("you can hear a faint purr!");
//    }
}
