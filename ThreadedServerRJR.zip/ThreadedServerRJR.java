package Threaded_CS_RJR;

/*
 * RJRs threaded server. Two classes are now used together with the RunnableInterface.
 *
 * The first class (Connection) is threaded and handles the reading and writing between the clients.
 *
 * The second class ThreadedServer creates the database and starts the threads as clients try to connect.
 *
 * 06 February 2012
 */
import java.io.*;
import java.util.*;
import java.net.*;

public class ThreadedServerRJR {

   private ServerSocket ss = null;
   private Socket s = null;
   private int clientCount = 0;  // Count of clients connecting
   private int connectionNum = 0;  // Count of clients connecting
   private Thread connThreads[];  // Array of threads
   private HashMap<String, String> names = null;

   public ThreadedServerRJR() {
      this.connThreads = new Thread[50];
      this.doServing();
   }  // end of constructor ThreadedServerRJR

   public void doServing() {

      System.out.println("RJR Threaded server starting");

      this.names = new HashMap();  // Set up the database
      this.names.put("Fred Smith", "F.Smith@cov.ac.uk");
      this.names.put("Joe Bloggs", "J.Bloggs@cov.ac.uk");
      this.names.put("Tim Nice", "T.Nice@cov.ac.uk");
      System.out.println("Database done");

      try {
         this.ss = new ServerSocket(2000);
         while (true) {
            this.s = ss.accept();
            this.clientCount++;
            System.out.println("Connection " + this.connectionNum
                    + " made: " + this.clientCount + " Clients connected");

            //Create and start thread to process client requests
            this.connThreads[this.connectionNum] = new Thread(new ConnectionRJR(s, names));
            this.connThreads[this.connectionNum].start();

            for (int i = 0; i < this.connectionNum; i++) {
               if (!this.connThreads[i].isAlive()) {
                  this.connThreads[i] = null;
                  this.clientCount--;
                  System.out.println("Connection " + i + " dead: "
                          + this.clientCount + " Clients connected");
               }  // end if
            }  // end for
            this.connectionNum++;
         }  // end while
      } catch (IOException e) {
         System.out.println("Trouble making a connection" + e);
      }
   }  // end of method doServing

   public static void main(String[] args) {
      new ThreadedServerRJR();
   }  // end of method main
}  // end of class ThreadedServer