package Threaded_CS_RJR;

/* RJRs connection for a threaded server. Two classes are now used together with the Runnable Interface.
 *
 * ConnectionRJR is threaded and handles the reading and writing between the clients.
 *
 * ThreadedServerRJR creates the database and starts the threads as clients try to connect.
 *
 * 06 February 2012 */
 
import java.io.*;
import java.util.*;
import java.net.*;

class ConnectionRJR implements Runnable {

   private Socket s;
   private HashMap<String, String> names;   
   private InputStream is = null;  // Streams definition for connection
   private OutputStream os = null;  
   private PrintWriter pw = null;  // Writers and readers for communication
   private BufferedReader br = null;
   private String lineRead = ""; // String read from client
   private Object jObj; // Used for assessing the HashMap
   private String reply = ""; // Reply to be sent to the client

   ConnectionRJR(Socket s, HashMap names) {
      this.s = s;
      this.names = names;
   }  // end of ConnectionRJR constructor

   public void run() {  // Implement Runnable's abstract run method

      // Get Streams for the particular Socket
      try {
         this.is = this.s.getInputStream();
         this.os = this.s.getOutputStream();
         this.pw = new PrintWriter(this.os, true);
         this.br = new BufferedReader(new InputStreamReader(this.is));
         System.out.println("RJR Threaded system set up");

         // Read and process names until the client tells the server
         // the service is no longer required.
         this.lineRead = "";
         while (true) {
            this.lineRead = this.br.readLine();
            if (this.lineRead.equals("Exit")) {
               break;
            }
            this.jObj = names.get(this.lineRead);
            if (this.jObj == null) {
               this.reply = "User not known";
            } else {
               this.reply = (String) this.jObj;
            }
            this.pw.println(this.reply);
         }
         this.pw.close();
         this.br.close();
         this.is.close();
         this.os.close();
         System.out.println("RJR Connection Closed down");
      } catch (IOException e) {
         System.out.println("Trouble with connection to client" + e);
      }  // end of try-catch
   }  // end of method run
}  // end of class ConnectionRJR